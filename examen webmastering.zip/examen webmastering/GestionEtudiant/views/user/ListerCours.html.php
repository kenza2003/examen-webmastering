<?php 
use ism\models\CoursModel;
$model = new CoursModel();
$data = $model->selectAll();
?> 
<!DOCTYPE html>

<html>
    <head>
        <title>ListerCours</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

 
  </head>

    <body>

<h1 class="container d-flex hw-100" >ListerCours</h1>
<div class="panel body">

                <table class="table table-striped space">
                <thead class="space">
                            <th>idCours</th>
                            <th>classeCours</th>
                            <th>moduleCours</th>
                            <th>professeurCours</th>
                            <th>semestreCours</th>
                        </thead>
                        <tbody>
                        <?php foreach($data["data"] as $info ):?>
                        <tr>
                        <td><?= $info["idCours"]?></td>
                       <td><?= $info["classeCours"]?></td>
                       <td><?= $info["moduleCours"]?></td>
                       <td><?= $info["professeurCours"]?></td>
                       <td><?= $info["semestreCours"]?></td>
                        </tr>
                        <?php endforeach;?>
                        </tbody>
                </table>
               
</div>
</body>
</html>