<!-- <table class="table">
  <thead>
    <tr>
     
      <th scope="col">Matricule</th>
      <th scope="col">Nom</th>
      <th scope="col">Prenom</th>
      <th scope="col">Grade</th>

    </tr>
  </thead>
  <tbody>
  <?php foreach($professeur as $pr): ?>
    <tr>
      
      <td><?=$pr["matricule"];?></td>
      <td><?=$pr["nom"];?></td>
      <td><?=$pr["prenom"];?></td>
      <td><?=$pr["grade"];?></td>
    </tr>
     <?php endforeach ?>
  </tbody>
</table> -->
 <h1 class="display-4">Liste Professeurs</h1>