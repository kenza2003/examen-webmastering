<?php 
use ism\models\EtudiantModel;
$model = new EtudiantModel();
$data = $model->selectAll();
?>
<!DOCTYPE html>

<html>
    <head>
        <title>Liste Des Etudiants</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

 
  </head>

    <body>

<center><h1 class="container d-flex hw-100 text center">LA LISTE DES ETUDIANTS</h1></center>
<br>
<br>
<div class="panel body">

                <table class="table table-striped space">
                        
                        <thead class="space">
                            <th>Matricule</th>
                            <th>Nom</th>
                            <th>Prenom</th>
                            <th>classe</th>
                            <th>Parcour</th>
                            <th>Date de naissance</th>    
                            <th>Sexe</th>
                            <th>competence</th>
                        </thead>
                        <tbody>
                        <?php foreach($data["data"] as $info ):?>
                        <tr>
                        <td><?= $info["matriculeEtu"]?></td>
                       <td><?= $info["nomEtu"]?></td>
                       <td><?= $info["prenomEtu"]?></td>
                       <td><?= $info["classeEtu"]?></td>
                       <td><?= $info["parcoursEtu"]?></td>
                       <td><?= $info["dateNaissanceEtu"]?></td>
                       <td><?= $info["sexeEtu"]?></td>
                       <td><?= $info["competenceEtu"]?></td>
                        </tr>
                        <?php endforeach;?>
                        </tbody>
                        
                    </table>
            </div>
</body>
</html>