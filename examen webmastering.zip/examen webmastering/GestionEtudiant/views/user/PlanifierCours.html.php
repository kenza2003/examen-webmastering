



<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Plannification d'un  cours</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


</head>
<body>

<!-- if you want to create login page and register page together in one page ...you have to only chnage his name...that's it...                 -->
<div class="container" style="margin-top: 5%;">
  <div class="row">
    <div class="col-sm-4"> </div>
<div class="col-md-4">
  
<h1 class="text-center">Plannification d'un cours</h1>



<form action="#">

  <div >
    <label for="UserName">Nom du Cours</label>
    <input type="text" class="form-control" id="nom">
  </div>
  <div >
    <label for="UserName">Nom du Professeur</label>
    <input type="text" class="form-control" id="nom">
  </div>
  <div  >
    <label for="UserName">salle</label>
    <input type="number" class="form-control" id="salle" >
  </div>
  <div >
    <label for="UserName">Datedebut</label>
    <input type="date" class="form-control" id="date">
  </div>
  <div >
    <label for="UserName">Datefin</label>
    <input type="date" class="form-control" id="date">
  </div>
  
  <div >
                    <label for="pet-select" >
                        Niveau 
                        
                    </label>
                    <select class="form-control">
														<option disabled="" selected=""></option>
                            <option value="1ere année">1ere année</option>
                            <option value="2eme année">2eme année</option>
                            <option value="3eme année">3eme année</option>
                        </select>
                        
                      
    </div>
                    <div >
                    <label for="pet-select">
                        filiere 
                    </label>
                    <select class="form-control">
							<option disabled="" selected=""></option>
                            <option value="GLRS">GLRS</option>
                            <option value="MAE">MAE</option>
                            <option value="IAGE">IAGE</option>
                            <option value="TTL">TTL</option>
                            <option value="ETSE">ETSE</option>
                        </select>
                    </div>
                    <br>
                  
                    



  <button  type="submit" class="btn btn-default" style="text-align: center;">valider</button><br>

</form>
<br/>
    </div>
   </div>
  </div>
</div>
</div>
</body>
</html>
