<!DOCTYPE html>

<html>
    <head>
        <title>ESPACE RESPONSABLE</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

 
  </head>

    <body>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js"></script>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" rel=""/>
    <nav class="navbar navbar-toggleable-md navbar-light bg-faded">
    <ul class="sub">
    <li class="list-group-item">
    
    <a class="nav-link dropdown-toggle" href="" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      OPTIONS
      
    </a>
    <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
         <a class="list-group-item" href="<?php path("user/PlanifierCours") ?>">Planifier un cours</a>
         <a class="list-group-item" href="<?php path("user/ListeEtudiant") ?>">Lister les etudiants</a>
         <a class="list-group-item" href="<?php path("security/register") ?>">Ajouter professeur</a>
         <a class="list-group-item" href="<?php path("user/ListerCoursProfesseur") ?>">Lister les cours</a>
    </div>
  </li>
</ul>
<h1 class="container d-flex hw-100" >ESPACE RESPONSABLE</h1>
</nav>
<div class="panel body">
  
                <table class="table table-striped space">
                        
                        <thead class="space">
                        <th>Matricule</th>
                            <th>Nom</th>
                            <th>Prenom</th>
                            <th>Classe</th>
                            <th>Date de naissance</th>
                            <th>Email</th>
                            <th>Sexe</th>
                            <th>Avatar</th>
                        </thead>
                        
                    </table>
            </div>
</body>
</html>
