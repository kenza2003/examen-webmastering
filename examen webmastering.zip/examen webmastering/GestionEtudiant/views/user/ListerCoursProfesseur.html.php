 
<!DOCTYPE html>

<html>
    <head>
        <title>Cours du professeur</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

 
  </head>

    <body>

<h1 class="container d-flex hw-100" >Cours du professeur</h1>
<div class="panel body">

                <table class="table table-striped space">
                 <tr>
                    <th>Heure debut</th>
                </tr>
                <tr>
                    <th>Heure fin</th>
                </tr>       
                        <thead class="space">
                
                            <th>HORAIRE</th>
                            <th>Lundi</th>
                            <th>Mardi</th>
                            <th>Mercredi</th>
                            <th>Jeudi</th>
                            <th>Vendredi</th>
                        </thead>
                        
                </table>
               
</div>
</body>
</html>