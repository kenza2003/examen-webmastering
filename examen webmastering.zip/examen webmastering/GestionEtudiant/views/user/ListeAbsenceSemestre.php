<!DOCTYPE html>

<html>
    <head>
        <title>Liste Absence Semestre</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

 
  </head>

    <body>
    

<h1 class="container d-flex hw-100" >Liste Absence Semestre</h1>
</nav>
<div class="panel body">

                <table class="table table-striped space">
                        
                        <thead class="space">
                            <th>Matricule</th>
                            <th>Nom</th>
                            <th>Prenom</th>
                            <th>Classe</th>
                            <th>Cours</th>
                            <th>Semestre</th>
                        </thead>
                        
                    </table>
            </div>
</body>
</html>
