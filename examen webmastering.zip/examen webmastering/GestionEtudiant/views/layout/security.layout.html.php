<?php 
require_once(ROOT_VIEWS_INC."header.inc.php");
require_once(ROOT_VIEWS_INC."menu.inc.php");
echo "layout security";
echo $content_for_layout;
?>




<?php 
require_once(ROOT_VIEWS_INC."footer.inc.php");
?>