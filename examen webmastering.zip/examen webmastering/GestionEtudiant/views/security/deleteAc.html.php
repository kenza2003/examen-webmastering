<?php
use ism\lib\Session;
use ism\config\helper;
use ism\models\UserModel;

$model = new UserModel();
$data = $model->selectAll();
//dd($data);
?>
<form action="<?php path("security/deleteAc")?>" method="post">
<div class="container mt-5 ">
<h1> Supprimer</h1>

<div> 
<select class="form-control" name="login">
<?php foreach($data['data'] as $info ) : if ($info["role"] == "ROLE_AC") : ?>
<option value="<?=$info["login"] ?>"><?= $info["nom"] ?></option>
<?php endif; endforeach; ?>
</select>
</div>
</div>

<div class="row mt-4">
            <div class="col-md-1">
            </div>
            <div class="pl-1">
                <button type="submit" class="btn btn-outline-primary"><h4>supprimer</h4></button>
            </div>
        </div>
</form>