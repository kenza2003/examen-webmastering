<?php
use ism\lib\Session;
use ism\config\helper;
use ism\models\AbsenceModel;

$model = new AbsenceModel();
$data = $model->selectAll();
//dd($data);
?>