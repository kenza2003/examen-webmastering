<?php
use ism\lib\Session;
use ism\config\helper;
use ism\models\AbsenceModel;
use ism\models\ProfesseurModel;

$model = new ProfesseurModel();
$data = $model->selectAll();
//dd($data);
?>