<?php
use ism\lib\Session;
use ism\config\helper;
use ism\models\UserModel;
use ism\models\CoursModel;


$model = new CoursModel();
$data = $model->selectAll();
//dd($data);
?>