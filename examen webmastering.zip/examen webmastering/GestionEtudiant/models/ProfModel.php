<?php
namespace ism\models;
use ism\lib\FormatDate;
use ism\lib\AbstractModel;

class ProfesseurModel extends AbstractModel
{
    public function __construct()
    {
        parent::__construct();
        $this->tableName = "professeur";
        $this->primaryKey = "id";
    }
    public function insertProf(array $user){
        extract($user);
        $sql = "INSERT INTO professeur
        (login,password,matriculeProf,nomProf,prenomProf,dateNaissanceProf,sexeProf,gradeProf,classeProf,
        moduleProf,role)
        VALUES 
        (?,?,?,?,?,?,?,?,?,?,?)";
        $result = $this->persit($sql, [$login,$password,$matricule, $nom, $prenom,FormatDate::createDateEn(), $sexe, $classe, $competence, $avatar, $parcours,$role]);
        return $result["count"] == 0 ? false : true;
    }

    public function updateProf(array $user):bool{
        extract($user);
        $sql="UPDATE $this->tableName SET nomProf=? WHERE matriculeProf=? ";
        $result= $this->persit($sql,[$user],true);
        return $result["count"] == 0 ? true : false;

    }
}