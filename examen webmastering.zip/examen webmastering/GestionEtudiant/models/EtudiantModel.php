<?php
namespace ism\models;
use ism\lib\FormatDate;
use ism\lib\AbstractModel;

class EtudiantModel extends AbstractModel
{
    public function __construct()
    {
        parent::__construct();
        $this->tableName = "etudiant";
        $this->primaryKey = "id";
    }
    public function inserertEtu(array $user){
        extract($user);
        $sql = "INSERT INTO etudiant 
        (login,password,matriculeEtu,nomEtu,prenomEtu,dateNaissanceEtu,sexeEtu,classeEtu,
        competenceEtu,parcoursEtu,role)
        VALUES 
        (?,?,?,?,?,?,?,?,?,?,?)";
        $result = $this->persit($sql, [$login,$password,$matricule,$nom,$prenom,FormatDate::createDateEn(),$sexe,$classe,$competence,$avatar,$parcours,$role]);
        return $result["count"] == 0 ? false : true;
    }
    public function showEtudByClass(string $classe):array{
        $sql="SELECT * FROM $this->tableName WHERE classe=?";
        $result=$this->showEtudByClass($sql,[$classe],true);
        return $result["count"]==0?[]:$result["data"];
    }

    public function modifierEtu(array $user):bool{
        extract($user);
        $sql="UPDATE $this->tableName SET nomEtu=? WHERE matriculeEtu=? ";
        $result= $this->persit($sql,[$user],true);
        return $result["count"] == 0 ? true : false;

    }
    public function listCoursbyEtud($coursId):array{
        $sql = "SELECT * libelleCours FROM cours c,etudiant e WHERE e.matEtu=c.etuMat";
        $result = $this->selectBy($sql, [$coursId], true);
        return $result;
    }
}