<?php
namespace ism\controllers;

use ism\lib\Role;
use ism\lib\Request;
use ism\lib\Session;
use ism\lib\Response;
use ism\models\UserModel;
use ism\lib\AbstractModel;
use ism\lib\AbstractController;
use ism\models\RessourcesModel;

class RessourcesController extends AbstractController{
   
    public function __construct()
    {
        parent::__construct();
        $this->model= new UserModel();
    }

    public function inscrirEtu(){
        if(!Role::estAC())Response::redirectUrl("security/login");
        $matriculeEtu = Session::getSession("matriculeEtu");
        $classeEtu=Session::getSession("classeEtu");
        Session::destroyKey("matriculeEtu");
        Session::destroyKey("classeEtu");
        Session::destroyKey("action");
        $model = new UserModel();
        $model->insert(["matriculeEtu" => $matriculeEtu,"classeEtu" => $classeEtu]);
        Response::redirectUrl("user/showListeEtu/");
    }
     public function ajoutAC(){
        if(!Role::estAdmin())Response::redirectUrl("security/login");
        $login = Session::getSession("login");
        $role = Session::getSession("role");
        Session::destroyKey("login");
        Session::destroyKey("role");
        Session::destroyKey("action");
        $model = new UserModel();
        $model->insert(["login" => $login,"role" => $role]);
        if ($role=="ROLE_AC") {
            Response::redirectUrl("user/showListeAC");

        } else {
            Response::redirectUrl("user/showListeRP");

        }
    }
    
}

?>